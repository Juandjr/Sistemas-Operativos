
package Examen_U3_JuanJ_Linux;
import javax.swing.SwingUtilities;

/**
 *
 * @author CivilJuan
 */
public class Examen_U3_JuanJ_Linux {

    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> {
            Interfaz ventana = new Interfaz();
            ventana.setVisible(true);
        });
    }
    
}
