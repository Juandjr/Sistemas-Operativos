#!/bin/bash

gnome-terminal -- bash -c "sh ~/trabajos/gestionSegu.sh; exec bash"
