#!/bin/bash

gnome-terminal -- bash -c "sh ~/trabajos/gestionDisk.sh; exec bash"
