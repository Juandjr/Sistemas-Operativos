#!/bin/bash

# Actualizar el sistema
echo "Actualizando el sistema..."
sudo apt-get update


# Instalar paquetes necesarios
echo "Instalando paquetes necesarios..."
sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common

# Agregar la clave GPG de Docker
echo "Agregando la clave GPG de Docker..."
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo apt-key add -

# Agregar el repositorio de Docker
echo "Agregando el repositorio de Docker..."
echo "deb [arch=amd64] https://download.docker.com/linux/debian $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Actualizar el índice de paquetes
echo "Actualizando el índice de paquetes..."
sudo apt-get update

# Instalar Docker
echo "Instalando Docker..."
sudo apt-get install -y docker-ce

# Verificar que Docker está corriendo
echo "Verificando el estado de Docker..."
sudo systemctl status docker --no-pager

# Agregar el usuario actual al grupo docker para ejecutar comandos sin sudo
echo "Agregando el usuario al grupo docker..."
sudo usermod -aG docker $USER

# Confirmar instalación
echo "Docker se ha instalado correctamente. Verificando la versión de Docker..."
docker --version

echo "Instalación completa. Por favor, cierre la sesión y vuelva a iniciarla para aplicar los cambios del grupo docker."

