#!/bin/bash

# Script para verificación de seguridad en Debian

# Función para esperar 5 segundos
esperar() {
    echo "Esperando 5 segundos..."
    sleep 5
}

# Verificación de actualizaciones disponibles
echo "Verificando actualizaciones disponibles..."
sudo apt update && sudo apt list --upgradable
esperar

# Verificación de puertos abiertos
echo "Verificando puertos abiertos..."
sudo netstat -tuln
esperar

# Verificación de usuarios con permisos sudo
echo "Verificando usuarios con permisos sudo..."
sudo grep '^sudo' /etc/group
esperar

# Verificación de configuración de firewall (ufw)
if command -v ufw &> /dev/null; then
    echo "Verificando configuración de firewall (ufw)..."
    sudo ufw status verbose
else
    echo "ufw no está instalado en el sistema."
fi
esperar

# Verificación de archivos de configuración críticos
echo "Verificando archivos de configuración críticos..."
echo "Contenido de /etc/passwd:"
cat /etc/passwd | head -n 10
esperar

echo "Contenido de /etc/shadow:"
sudo cat /etc/shadow | head -n 10
esperar

echo "Operaciones de verificación de seguridad completadas."
