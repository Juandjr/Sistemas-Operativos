#!/bin/bash

gnome-terminal -- bash -c "sh /home/debianjuanj/trabajos/MiguelMolina.sh; exec bash"
