#!/bin/bash

gnome-terminal -- bash -c "sh /home/debianjuanj/trabajos/ScripEjemploAlmacenamiento.sh; exec bash"
