#!/bin/bash

# Directorio de limpieza
CLEANUP_DIR="/tmp/cleanup"

# Función para mostrar el uso del disco
show_disk_usage() {
    echo "Uso del disco:"
    df -h
    echo
    sleep 5
    echo "Mostrando con el tipo de archivo:"
    df -T
    echo
    sleep 5
    echo "Lista de dispositivos de bloques:"
    lsblk
    echo
    sleep 5
}

# Función para limpiar archivos temporales
cleanup_temp_files() {

    echo "Mostrando en pantalla el contenido de las carpetas Temporales"
    ls /tmp/*
    echo   
    sleep 5
    echo "Limpiando archivos temporales..."

    # Limpiar /tmp
    sudo rm -rf /tmp/*
    echo "/tmp limpiado."
    sleep 5

    # Limpiar /var/tmp
    sudo rm -rf /var/tmp/*
    echo "/var/tmp limpiado."
    sleep 5

    # Muestra un mensaje de que se termino de limpiar
    echo "Limpieza completada."
    echo
}


# Función Main
main() {
    #llamada a las funciones
    show_disk_usage
    cleanup_temp_files
}

# Ejecutar la función principal
main
