#!/bin/bash

# Script para gestión de discos en Debian

# Función para esperar 5 segundos
esperar() {
    echo "Esperando 5 segundos..."
    sleep 5
}

# Mostrar la información de los discos
echo "Información de los discos:"
lsblk -f
esperar

# Mostrar información detallada de los discos
echo "Información detallada de los discos:"
sudo fdisk -l
esperar

# Crear una partición
# Cambia /dev/sdX por el disco en el que deseas crear la partición
DISCO="/dev/sdX"
PARTICION="${DISCO}1"
echo "Creando una partición en $DISCO..."
echo -e "n\np\n1\n\n\nw" | sudo fdisk $DISCO
esperar

# Mostrar información después de crear la partición
echo "Información de los discos después de crear la partición:"
lsblk -f
esperar

# Eliminar una partición
# Cambia ${DISCO}1 por la partición que deseas eliminar
echo "Eliminando la partición $PARTICION..."
echo -e "d\n1\nw" | sudo fdisk $DISCO
esperar

# Mostrar información después de eliminar la partición
echo "Información de los discos después de eliminar la partición:"
lsblk -f
esperar

echo "Operaciones completadas."
