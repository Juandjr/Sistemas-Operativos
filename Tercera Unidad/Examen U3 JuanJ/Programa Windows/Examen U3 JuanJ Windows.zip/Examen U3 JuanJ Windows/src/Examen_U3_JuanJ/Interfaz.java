package Examen_U3_JuanJ;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;


public class Interfaz extends JFrame {
    
    public Interfaz(){
   // Configuración básica de la ventana
        setTitle("Examen 3 JuanJ");
        setSize(1280, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel principal con fondo personalizado
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                // Cargar y dibujar las imágenes en el fondo
                Image imagen3 = new ImageIcon(getClass().getResource("/images/xd.png")).getImage();
                Image imagen = new ImageIcon(getClass().getResource("/images/Fondotitulo.png")).getImage();
                Image imagen1 = new ImageIcon(getClass().getResource("/images/120950738_p1a.jpg")).getImage();
                Image imagen2 = new ImageIcon(getClass().getResource("/images/120521101_p0a.jpg")).getImage();
                Image imagen4 = new ImageIcon(getClass().getResource("/images/A.png")).getImage();
                Image imagen5 = new ImageIcon(getClass().getResource("/images/A.png")).getImage();
                Image imagen6 = new ImageIcon(getClass().getResource("/images/A.png")).getImage();
                Image imagen7 = new ImageIcon(getClass().getResource("/images/A.png")).getImage();
                Image imagen8 = new ImageIcon(getClass().getResource("/images/B.png")).getImage();
                Image imagen9 = new ImageIcon(getClass().getResource("/images/C.png")).getImage();
                Image imagen10 = new ImageIcon(getClass().getResource("/images/zi.png")).getImage();
                Image imagen11 = new ImageIcon(getClass().getResource("/images/Honami.png")).getImage();

                // Dibujar las imágenes en posiciones específicas
                g.drawImage(imagen3, 216, 1, this);
                g.drawImage(imagen, 216, 1, this);
                g.drawImage(imagen9, 216, 108, this);
                g.drawImage(imagen10, 210, 115, this);
                g.drawImage(imagen11, 860, 130, this);
                g.drawImage(imagen2, 1050, 1, this);
                g.drawImage(imagen4, 355, 180, this);
                g.drawImage(imagen5, 675, 180, this);
                g.drawImage(imagen6, 355, 355, this);
                g.drawImage(imagen7, 675, 355, this);
                g.drawImage(imagen8, 216, 650, this);
                g.drawImage(imagen1, -600, -150, this);
                g.drawImage(imagen2, 1050, 1, this);

            }
        };

        panelFondo.setLayout(null);

        // Crear y agregar los 4 botones
        ImageIcon icono = new ImageIcon(getClass().getResource("/images/Almacen-de-datos1.png")); // Cambia la ruta por la ubicación de tu imagen
        JButton boton1 = new JButton(icono);
        boton1.setBounds(359, 225, 242, 100);
        ImageIcon icono2 = new ImageIcon(getClass().getResource("/images/segu.png"));
        JButton boton2 = new JButton(icono2);
        boton2.setBounds(679, 225, 242, 100);
        ImageIcon icono3 = new ImageIcon(getClass().getResource("/images/discos.png"));
        JButton boton3 = new JButton(icono3);
        boton3.setBounds(359, 400, 242, 100);
        ImageIcon icono4 = new ImageIcon(getClass().getResource("/images/docker.png"));
        JButton boton4 = new JButton(icono4);
        boton4.setBounds(679, 400, 242, 100);
        
        
        
        // Dandole funciones a los botones
        //boton 1 = boton para gestion de Almacenamineto
        boton1.addActionListener((ActionEvent e) -> {
            try {
                File archivo = new File("C:\\Users\\CivilJuan\\Documents\\NetBeansProjects\\Laboratorio1y2_U3_JuanJ\\GestionAlmacenamiento.bat");
                
                // Verificar si Desktop es compatible con la plataforma
                if (Desktop.isDesktopSupported()) {
                    Desktop desktop = Desktop.getDesktop();
                    
                    // Verificar si se puede abrir el archivo
                    if (archivo.exists()) {
                        desktop.open(archivo); // Abre el archivo con la aplicación predeterminada del sistema
                    } else {
                        System.out.println("El archivo no existe.");
                    }
                } else {
                    System.out.println("Desktop no es compatible en esta plataforma.");
                }
            } catch (IOException j) {
            }
        });
        
        //boton 2 = boton para gestion de Seguridad
        boton2.addActionListener((ActionEvent e) -> {
            try {
                File archivo = new File("C:\\Users\\CivilJuan\\Documents\\NetBeansProjects\\Laboratorio1y2_U3_JuanJ\\GestionSeguridad.bat");
                
                // Verificar si Desktop es compatible con la plataforma
                if (Desktop.isDesktopSupported()) {
                    Desktop desktop = Desktop.getDesktop();
                    
                    // Verificar si se puede abrir el archivo
                    if (archivo.exists()) {
                        desktop.open(archivo); // Abre el archivo con la aplicación predeterminada del sistema
                    } else {
                        System.out.println("El archivo no existe.");
                    }
                } else {
                    System.out.println("Desktop no es compatible en esta plataforma.");
                }
            } catch (IOException j) {
            }
        });
        
        //boton 3 = boton para gestion de Discos
        boton3.addActionListener((ActionEvent e) -> {
            try {
                File archivo = new File("C:\\Users\\CivilJuan\\Documents\\NetBeansProjects\\Laboratorio1y2_U3_JuanJ\\GestionDiscos.bat");
                
                // Verificar si Desktop es compatible con la plataforma
                if (Desktop.isDesktopSupported()) {
                    Desktop desktop = Desktop.getDesktop();
                    
                    // Verificar si se puede abrir el archivo
                    if (archivo.exists()) {
                        desktop.open(archivo); // Abre el archivo con la aplicación predeterminada del sistema
                    } else {
                        System.out.println("El archivo no existe.");
                    }
                } else {
                    System.out.println("Desktop no es compatible en esta plataforma.");
                }
            } catch (IOException j) {
            }
        });
        
        //boton 4 = boton para gestion de Dockers
        boton4.addActionListener((ActionEvent e) -> {
            try {
                File archivo = new File("C:\\Users\\CivilJuan\\Documents\\NetBeansProjects\\Laboratorio1y2_U3_JuanJ\\GestionDocker.bat");
                
                // Verificar si Desktop es compatible con la plataforma
                if (Desktop.isDesktopSupported()) {
                    Desktop desktop = Desktop.getDesktop();
                    
                    // Verificar si se puede abrir el archivo
                    if (archivo.exists()) {
                        desktop.open(archivo); // Abre el archivo con la aplicación predeterminada del sistema
                    } else {
                        System.out.println("El archivo no existe.");
                    }
                } else {
                    System.out.println("Desktop no es compatible en esta plataforma.");
                }
            } catch (IOException j) {
            }
        });
        
        //Añadir texto a la ventana
        JLabel texto1 = new JLabel("Gestion del Almacenamiento");
        texto1.setBounds(380, 170, 250, 75);
        texto1.setFont(new Font("Sans", Font.BOLD, 15));
        JLabel texto2 = new JLabel("Gestion de Seguridad");
        texto2.setBounds(720, 170, 250, 75);
        texto2.setFont(new Font("Sans", Font.BOLD, 15));
        JLabel texto3 = new JLabel("Gestion de Discos");
        texto3.setBounds(415, 340, 150, 75);
        texto3.setFont(new Font("Sans", Font.BOLD, 15));
        JLabel texto4 = new JLabel("Gestion de Docker");
        texto4.setBounds(730, 340, 250, 75);
        texto4.setFont(new Font(" -", Font.BOLD, 15));
        JLabel titulo = new JLabel("AutoMatized Scripting");
        titulo.setBounds(510, 25, 500, 75);
        titulo.setFont(new Font("Sans", Font.BOLD, 25));
        JLabel creditos = new JLabel("Elaborado por: Juan Jiménez");
        creditos.setBounds(225, 630, 500, 75);
        creditos.setFont(new Font("Sans", Font.BOLD, 15));
        
        //agrega los objetos al Label del fondo  
        panelFondo.add(boton1);
        panelFondo.add(boton2);
        panelFondo.add(boton3);
        panelFondo.add(boton4);
        panelFondo.add(texto1);
        panelFondo.add(texto2);
        panelFondo.add(texto3);
        panelFondo.add(texto4);
        panelFondo.add(titulo);
        panelFondo.add(creditos);

        // Agregar el panel al JFrame
        add(panelFondo);
    }
}