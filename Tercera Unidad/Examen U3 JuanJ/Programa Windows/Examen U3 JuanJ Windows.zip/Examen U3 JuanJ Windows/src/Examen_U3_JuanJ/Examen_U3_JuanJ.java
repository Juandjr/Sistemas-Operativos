
package Examen_U3_JuanJ;
import javax.swing.SwingUtilities;

/**
 *
 * @author CivilJuan
 */
public class Examen_U3_JuanJ {

    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> {
            Interfaz ventana = new Interfaz();
            ventana.setVisible(true);
        });
    }
    
}
