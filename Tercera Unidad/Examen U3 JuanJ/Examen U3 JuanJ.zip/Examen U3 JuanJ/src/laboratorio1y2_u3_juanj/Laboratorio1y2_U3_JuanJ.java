
package laboratorio1y2_u3_juanj;
import javax.swing.SwingUtilities;

/**
 *
 * @author CivilJuan
 */
public class Laboratorio1y2_U3_JuanJ {

    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> {
            Interfaz ventana = new Interfaz();
            ventana.setVisible(true);
        });
    }
    
}
